<?php
/*
 * QAQ Model使用thinkphp组件
 * Author:烟雨寒云
 * Mail:admin@yyhy.me
 * Date:2020/04/26
 */

namespace QAQ\Kernel;

use think\Model as ThinkModel;

class Model extends ThinkModel
{
}